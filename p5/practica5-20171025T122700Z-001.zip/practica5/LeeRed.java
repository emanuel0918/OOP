public interface LeeRed {
	void leeRed(Object obj);
}
